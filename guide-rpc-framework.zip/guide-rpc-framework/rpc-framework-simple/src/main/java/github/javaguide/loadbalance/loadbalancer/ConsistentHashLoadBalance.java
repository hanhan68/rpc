package github.javaguide.loadbalance.loadbalancer;

import github.javaguide.loadbalance.AbstractLoadBalance;
import github.javaguide.remoting.dto.RpcRequest;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * refer to dubbo consistent hash load balance: https://github.com/apache/dubbo/blob/2d9583adf26a2d8bd6fb646243a9fe80a77e65d5/dubbo-cluster/src/main/java/org/apache/dubbo/rpc/cluster/loadbalance/ConsistentHashLoadBalance.java
 * @author RicardoZ
 * @createTime 2020年10月20日 18:15:20
 *
 * 一致性哈希：当有节点加入或离开时，只会影响相邻的部分，而不是整个系统
 */
@Slf4j
public class ConsistentHashLoadBalance extends AbstractLoadBalance {
    private final ConcurrentHashMap<String, ConsistentHashSelector> selectors = new ConcurrentHashMap<>(); //  rpcServiceName -> ConsistentHashSelector

    @Override
    protected String doSelect(List<String> serviceAddresses, RpcRequest rpcRequest) {
        int identityHashCode = System.identityHashCode(serviceAddresses); // 获取serviceAddresses的hashCode
        // build rpc service name by rpcRequest
        String rpcServiceName = rpcRequest.getRpcServiceName(); // 获取服务名
        ConsistentHashSelector selector = selectors.get(rpcServiceName); // 获取ConsistentHashSelector对象
        // check for updates
        if (selector == null || selector.identityHashCode != identityHashCode) { // 如果不存在或者地址列表已更新（identityHashCode 不一致）
            selectors.put(rpcServiceName, new ConsistentHashSelector(serviceAddresses, 160, identityHashCode));
            selector = selectors.get(rpcServiceName);
        }
        return selector.select(rpcServiceName + Arrays.stream(rpcRequest.getParameters())); // eg. java.util.stream.ReferencePipeline$Head@4b67cf4d
    }

    /**
     * 为什么一致性哈希用TreeMap作为哈希环?
     *  1. 按键排序, 进而可以进行高效的范围查询（因为需要按顺时针找到离某个哈希值最近的节点）
     *  2. 底层数据结构为 红黑树，高效的插入与删除操作
     */

    static class ConsistentHashSelector {
        private final TreeMap<Long, String> virtualInvokers; // 哈希环，<虚拟节点的hash值，服务地址>

        private final int identityHashCode;

        ConsistentHashSelector(List<String> invokers, int replicaNumber, int identityHashCode) {
            this.virtualInvokers = new TreeMap<>();
            this.identityHashCode = identityHashCode;

            for (String invoker : invokers) { // 一个真实节点，replicaNumber个虚拟节点
                for (int i = 0; i < replicaNumber / 4; i++) {
                    byte[] digest = md5(invoker + i);  // 一次md5操作很耗时，所以设计了一次md5操作，生成4个虚拟节点(MD5编码16字节，每次取4个字节，即32位)
                    for (int h = 0; h < 4; h++) {
                        long m = hash(digest, h);
                        virtualInvokers.put(m, invoker); // 虚拟节点放入哈希环
                    }
                }
            }
        }

        static byte[] md5(String key) {
            MessageDigest md;
            try {
                md = MessageDigest.getInstance("MD5");
                byte[] bytes = key.getBytes(StandardCharsets.UTF_8);
                md.update(bytes);
            } catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException(e.getMessage(), e);
            }
            return md.digest(); // 生成并返回 MD5 哈希值
        }

        /**
         * 当 idx = 0 时，取 digest[0], digest[1], digest[2], digest[3]
         * 当 idx = 1 时，取 digest[4], digest[5], digest[6], digest[7]
         * 当 idx = 2 时，取 digest[8], digest[9], digest[10], digest[11]
         * 当 idx = 3 时，取 digest[12], digest[13], digest[14], digest[15]
         * & 255 是为了将 byte 转换为无符号的 int（0 到 255）
         * 转换为 long 是为了后续移位操作
         * 移位组合成 32 位整数 （大端序）
         *  4294967295L == 2^32 - 1 == 0xFFFFFFFF，确保结果是一个32 位无符号整数
         */

        static long hash(byte[] digest, int idx) { // 一个16B的哈希值，取出其中的4B， 拼接返回
            return ((long) (digest[3 + idx * 4] & 255) << 24 |  // 移动到最前面
                    (long) (digest[2 + idx * 4] & 255) << 16 |
                    (long) (digest[1 + idx * 4] & 255) << 8 |
                    (long) (digest[idx * 4] & 255))  // 不移位
                    & 4294967295L;
        }

        /**
         * 根据 rpcServiceKey 选择一个 invoker
         * @param rpcServiceKey
         * @return
         */
        public String select(String rpcServiceKey) {
            byte[] digest = md5(rpcServiceKey);
            return selectForKey(hash(digest, 0));
        }

        /**
         * tailMap(hashCode, true)：返回一个子 Map，包含所有键 大于等于 hashCode 的节点。
         *  firstEntry()：取这个子 Map 中的第一个节点（即 顺时针最近的节点）。
         * @param hashCode
         * @return
         */
        public String selectForKey(long hashCode) {
            Map.Entry<Long, String> entry = virtualInvokers.tailMap(hashCode, true).firstEntry();

            if (entry == null) {
                entry = virtualInvokers.firstEntry();
            }

            return entry.getValue();
        }
    }
}
