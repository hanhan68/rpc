package github.javaguide.remoting.transport.netty.client;


import github.javaguide.enums.CompressTypeEnum;
import github.javaguide.enums.SerializationTypeEnum;
import github.javaguide.enums.ServiceDiscoveryEnum;
import github.javaguide.extension.ExtensionLoader;
import github.javaguide.factory.SingletonFactory;
import github.javaguide.registry.ServiceDiscovery;
import github.javaguide.remoting.constants.RpcConstants;
import github.javaguide.remoting.dto.RpcMessage;
import github.javaguide.remoting.dto.RpcRequest;
import github.javaguide.remoting.dto.RpcResponse;
import github.javaguide.remoting.transport.RpcRequestTransport;
import github.javaguide.remoting.transport.netty.codec.RpcMessageDecoder;
import github.javaguide.remoting.transport.netty.codec.RpcMessageEncoder;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.net.InetSocketAddress;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * initialize and close Bootstrap object
 *
 * @author shuang.kou
 * @createTime 2020年05月29日 17:51:00
 */
@Slf4j
public final class NettyRpcClient implements RpcRequestTransport {
    private final ServiceDiscovery serviceDiscovery;
    private final UnprocessedRequests unprocessedRequests;  // 缓存未完成的请求 ID 和对应的 CompletableFuture
    private final ChannelProvider channelProvider;
    private final Bootstrap bootstrap;
    private final EventLoopGroup eventLoopGroup;

    public NettyRpcClient() {
        // initialize resources such as EventLoopGroup, Bootstrap
        eventLoopGroup = new NioEventLoopGroup(); // 创建一个 NIO 线程组，用于处理客户端的 I/O 操作
        bootstrap = new Bootstrap();
        bootstrap.group(eventLoopGroup) // 指定 EventLoopGroup 来处理 Channel 的 I/O 操作
                .channel(NioSocketChannel.class) // 指定客户端的 channel 类型为 NIO 套接字通道
                .handler(new LoggingHandler(LogLevel.INFO)) // 添加一个日志处理器，用于打印连接和数据传输过程中的日志信息（调试用）。
                //  The timeout period of the connection.
                //  If this time is exceeded or the connection cannot be established, the connection fails.
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000) // 设置连接超时时间，5000ms（5秒）
                .handler(new ChannelInitializer<SocketChannel>() { // 一个初始化处理器，用于初始化 Channel 的 pipeline
                    @Override
                    protected void initChannel(SocketChannel ch) {
                        ChannelPipeline p = ch.pipeline();
                        // If no data is sent to the server within 15 seconds, a heartbeat request is sent
                        p.addLast(new IdleStateHandler(0, 5, 0, TimeUnit.SECONDS)); // 当 5 秒内没有发送数据时，会触发一个 写空闲事件（WRITE_IDLE），可以用于发送心跳包。
                        p.addLast(new RpcMessageEncoder()); // 添加自定义编码器
                        p.addLast(new RpcMessageDecoder()); // 添加自定义解码器
                        p.addLast(new NettyRpcClientHandler()); // 收到服务端的消息的处理器
                    }
                });
        this.serviceDiscovery = ExtensionLoader.getExtensionLoader(ServiceDiscovery.class).getExtension(ServiceDiscoveryEnum.ZK.getName());
        this.unprocessedRequests = SingletonFactory.getInstance(UnprocessedRequests.class);  // 用于保存尚未收到响应的请求
        this.channelProvider = SingletonFactory.getInstance(ChannelProvider.class); // 提供一下channelMap， 缓存已连接的Channel，进行复用
    }

    /**
     * connect server and get the channel ,so that you can send rpc message to server
     * @param inetSocketAddress server address
     * @return the channel
     */
    @SneakyThrows  // Lombok 提供的一个注解。它的作用是 自动处理受检异常（checked exceptions）
    public Channel doConnect(InetSocketAddress inetSocketAddress) {
        CompletableFuture<Channel> completableFuture = new CompletableFuture<>();
        bootstrap.connect(inetSocketAddress).addListener((ChannelFutureListener) future -> { // 监听连接结果
            if (future.isSuccess()) {
                log.info("The client has connected [{}] successful!", inetSocketAddress.toString());
                completableFuture.complete(future.channel()); // future中 获取channel，完成异步任务
            } else {
                throw new IllegalStateException();
            }
        });
        return completableFuture.get();  // 调用 complete(...) 时，get() 返回对应的 Channel。
    }

    @Override
    public Object sendRpcRequest(RpcRequest rpcRequest) {
        CompletableFuture<RpcResponse<Object>> resultFuture = new CompletableFuture<>();
        // 1. 获取服务的地址
        InetSocketAddress inetSocketAddress = serviceDiscovery.lookupService(rpcRequest);
        // 2. 获取channel
        Channel channel = getChannel(inetSocketAddress);
        if (channel.isActive()) {
            // 3.发送请求
            unprocessedRequests.put(rpcRequest.getRequestId(), resultFuture);  // 未完成请求放入map
            RpcMessage rpcMessage = RpcMessage.builder()
                    .data(rpcRequest)
                    .codec(SerializationTypeEnum.HESSIAN.getCode())
                    .compress(CompressTypeEnum.GZIP.getCode())
                    .messageType(RpcConstants.REQUEST_TYPE).build();
            channel.writeAndFlush(rpcMessage).addListener((ChannelFutureListener) future -> { // 发送请求，并添加一个监听器，如果发送成功则将结果放入resultFuture
                if (future.isSuccess()) {
                    log.info("client send message: [{}]", rpcMessage);
                    // NettyRpcClientHandler 自动将异步回调的结果放入resultFuture
                } else {
                    future.channel().close();
                    resultFuture.completeExceptionally(future.cause()); // 出现异常，则将异常信息放入resultFuture
                    log.error("Send failed:", future.cause());
                }
            });
        } else {
            throw new IllegalStateException();
        }
        // 4. 得到响应的结果
        try {
            return resultFuture.get(); // 获取结果， 即远程方法调用的结果
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException("rpc请求失败," + e.getMessage());
        }
    }

    public Channel getChannel(InetSocketAddress inetSocketAddress) {
        Channel channel = channelProvider.get(inetSocketAddress); // 从缓存的map中获取channel
        if (channel == null) {
            channel = doConnect(inetSocketAddress); // 如果缓存中没有，则通过连接去获取 channel
            channelProvider.set(inetSocketAddress, channel);
        }
        return channel;
    }

    public void close() {
        eventLoopGroup.shutdownGracefully();
    }  // 优雅关闭线程组
}
