package github.javaguide.serialize.hessian;


import com.caucho.hessian.io.HessianInput;
import com.caucho.hessian.io.HessianOutput;
import github.javaguide.exception.SerializeException;
import github.javaguide.serialize.Serializer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * Hessian is a dynamically-typed, binary serialization and Web Services protocol designed for object-oriented transmission.
 *
 * @author Vinlee Xiao
 * @createTime 2022/2/23 21:11
 */
public class HessianSerializer implements Serializer {
    @Override
    public byte[] serialize(Object obj) {
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) { // 创建字节数组输出流
            HessianOutput hessianOutput = new HessianOutput(byteArrayOutputStream); // 创建一个 Hessian 序列化器，并将它绑定到一个 ByteArrayOutputStream 上，用于将 Java 对象序列化为二进制格式并写入到内存流中。
            hessianOutput.writeObject(obj); //  核心方法。将 Java 对象序列化为二进制格式并写入到内存流中。
            return byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            throw new SerializeException("Serialization failed");
        }
    }

    @Override
    public <T> T deserialize(byte[] bytes, Class<T> clazz) {
        try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes)) {
            HessianInput hessianInput = new HessianInput(byteArrayInputStream); // 创建一个 Hessian 反序列化器，并将它绑定到一个 ByteArrayInputStream 上，用于从内存流中读取二进制格式的数据并将其反序列化为 Java 对象。
            Object o = hessianInput.readObject(); // 从内存流中读取对象
            return clazz.cast(o);
        } catch (Exception e) {
            throw new SerializeException("Deserialization failed");
        }
    }
}
