package github.javaguide;

import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public class LinearIdObfuscator {
    // 精心选择的系数（保证30位输出）
    private static final long A = 10243;  // 13 + 4位
    private static final long B = 10253;  // 最大10 + 4位
    
    /**
     * 生成混淆ID（保证30位正数）
     * @param timestamp 13位时间戳（毫秒）
     * @param id 自增ID（建议≤10位）
     * @return 混淆后的30位正数ID
     */
    public static synchronized long obfuscate(long timestamp, long id) {
        long second = getSecond();
        System.out.print("时间戳: " + timestamp + " + ID: " + id + " C: " + second);
        return A * timestamp + B * id + second; // 取30位（10^9 ~ 10^30-1）
    }

    public static long getSecond(){
        // 获取当前 UTC 时间
        ZonedDateTime nowUtc = ZonedDateTime.now(ZoneOffset.UTC);

        // 提取当天的时间部分（时、分、秒）
        LocalTime timeOfDay = nowUtc.toLocalTime();

        // 计算从 00:00:00 UTC 到现在经过了多少秒
        return timeOfDay.toSecondOfDay();
    }

    // 测试
    public static void main(String[] args) throws InterruptedException {
        // 连续ID测试
        for(long id = 1; id <= 100; id++) {
            long timestamp = System.currentTimeMillis();
            long obfId = obfuscate(timestamp, id);
            System.out.printf(" 混淆ID: %d%n",obfId);
            Thread.sleep(100);
        }
        
        // 验证30位输出
        long maxId = obfuscate(9_999_999_999_999L, 9_999_999_999L);
        System.out.println("最大输出位数: " + (int)Math.log10(maxId) + "位");
        System.out.println("最大输出ID: " + maxId);
    }
}