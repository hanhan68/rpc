package github.javaguide;

public class InterleavedIdGenerator {

    private static long autoIncrementId = 0; // 自增ID，从0开始

    // 生成交错拼接的ID
    public static synchronized String generateInterleavedId() {
        long timestamp = System.currentTimeMillis(); // 13位时间戳
        long currentId = autoIncrementId++;         // 自增

        // 格式化ID为10位，不足补0
        String idStr = String.format("%010d", currentId);
        String timeStr = String.valueOf(timestamp);

        // 交错拼接
        StringBuilder result = new StringBuilder();
        int maxLen = Math.max(timeStr.length(), idStr.length());

        for (int i = 0; i < maxLen; i++) {
            if (i < timeStr.length()) {
                result.append(timeStr.charAt(i));
            }
            if (i < idStr.length()) {
                result.append(idStr.charAt(i));
            }
        }

        return result.toString();
    }

    public static void main(String[] args) {
        // 生成几个ID测试
        for (int i = 0; i < 100; i++) {
            try {
                Thread.sleep(1); // 确保时间戳变化（可选）
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("生成ID: " + generateInterleavedId());
        }
    }
}