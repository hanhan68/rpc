/**
 * @description 注册中心
 * @author Fuzhengwei bugstack.cn @小傅哥
 * @create 2024-05-12 15:35
 */
package cn.bugstack.middleware.dynamic.thread.pool.sdk.registry;