/**
 * @description auto config 配置入口
 * @author Fuzhengwei bugstack.cn @小傅哥
 * @create 2024-05-12 15:36
 */
package cn.bugstack.middleware.dynamic.thread.pool.sdk.config;