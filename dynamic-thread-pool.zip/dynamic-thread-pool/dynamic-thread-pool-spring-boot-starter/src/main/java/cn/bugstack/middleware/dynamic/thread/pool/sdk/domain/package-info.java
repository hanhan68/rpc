/**
 * @description 领域功能，动态线程池服务
 * @author Fuzhengwei bugstack.cn @小傅哥
 * @create 2024-05-12 15:35
 */
package cn.bugstack.middleware.dynamic.thread.pool.sdk.domain;